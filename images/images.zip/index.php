<?php require_once ('header.php'); ?>
<h1>Welcome to eMarket</h1>
<p>
    <img src="http://localhost/start/images/1(3).jpg" alt="p1" style="float: left" />
    <img src="http://localhost/start/images/2(3).jpg" alt="p2" style="float: right" />
</p>
<p>
    <img src="http://localhost/start/images/2(2).jpg" alt="p1" style="float: left; margin-top: 10px" width="300" />
    <img src="http://localhost/start/images/4(2).jpg" alt="p2" style="float: right; margin-top: 10px" />
</p>
<p style="margin-top: 20px;">
    <img src="http://localhost/start/images/brand1.png" alt="p1" style="float: left; margin: 20px 20px" />
    <img src="http://localhost/start/images/brand2.png" alt="p1" style="float: left; margin: 20px 20px" />
    <img src="http://localhost/start/images/brand3.png" alt="p1" style="float: left; margin: 20px 20px" />
</p>
<p style="margin-top: 20px;">
    <img src="http://localhost/start/images/brand4.png" alt="p1" style="float: left; margin: 20px 20px" />
    <img src="http://localhost/start/images/brand5.png" alt="p1" style="float: left; margin: 20px 20px" />
    <img src="http://localhost/start/images/brand6.png" alt="p1" style="float: left; margin: 20px 20px" />
</p>
<?php require_once ('footer.php'); ?>